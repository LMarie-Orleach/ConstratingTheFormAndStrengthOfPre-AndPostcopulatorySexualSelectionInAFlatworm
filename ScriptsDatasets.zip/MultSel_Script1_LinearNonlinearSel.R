# Lucas Marie-Orleach - March 2023

# script used to carry the analyses reported in the paper entitled "Contrasting the form and strength of pre- and postcopulatory
# sexual selection in a transparent worm with fluorescent sperm" by Lucas Marie-Orleach, Matt D. Hall, and Lukas Sch�rer.

# most functions below come from the supplementary material of Keagy et al 2016 Ecol. Lett 19: 71-80.

# 1. Load required packages

library(gss)
library(lme4)
library(parallel)
library(car)


# 2. Define functions

se  <- function(x) {
  # function to compute standard errors
  sd(x)/sqrt(length(x)) 
} 
rel <- function(x) { 
  # function to relativize fitness data
  (x[,1])/mean(x[,1],na.rm=TRUE) 
} 
standardise <- function(traits) {
  # function to standardise trait values
  # ARGUMENTS: traits = matrix of traits
  # RETURNS:   STtraits = matrix of standardized trait values
  #            means  = mean of each trait, before standardisation
  #            sds    = standard deviation of each trait, before standardisation
  
  STtraits <- traits
  means <- rep(NA, length(traits))
  names(means) <- colnames(traits)
  sds <- means
  for (i in 1:length(traits)) {
    means[i] <- sapply(traits[i], mean, na.rm = TRUE)
    sds[i] <- sapply(traits[i], sd, na.rm = TRUE)
    STtraits[i] <- (traits[i] - means[i]) / sds[i]
  }
  return(list(STtraits))
}
seldiff <- function(Rfitness, STtraits) {
  # univariate selection differentials function
  
  # ARGUMENTS: Rfitness = single-column data frame containing the fitness variable
  #            traits = matrix of traits
  
  # RETURNS:   sdiff = univariate selection differentials
  
  num_traits <- length(STtraits)
  dset  <- as.data.frame(cbind(Rfitness, STtraits))
  form  <- as.formula(paste(names(Rfitness), "~", names(STtraits[1])))
  x     <- summary(lm(form, dset))
  sdiff <- t(as.data.frame(x$coefficients[2, ]))
  rownames(sdiff) <- names(STtraits)[1]
  if (num_traits > 1) {
    for (i in 2:num_traits) {
      form <- as.formula(paste(names(Rfitness), "~", names(STtraits[i])))
      x <- summary(lm(form, dset))
      sdiff <- rbind(sdiff, x$coefficients[2, ])
    }
    rownames(sdiff) <- names(STtraits)
  }
  return(sdiff)
}
UNInonlin <- function(Rfitness, STtraits) {
  # univariate nonlinear selection differentials function
  # ARGUMENTS: Rfitness = single-column data frame containing fitness variable
  #            STtraits  = matrix of traits
  # RETURNS:   uninonlin = nonlinear (quadratic) selection differentials
  
  num_traits <- length(STtraits)
  dset       <- as.data.frame(cbind(Rfitness, STtraits))
  form       <- as.formula(paste(names(Rfitness), "~", names(STtraits[1]), "+", "I(", names(STtraits[1]), "^2)"))
  x          <- summary(lm(form, dset))
  uninonlin  <- t(as.data.frame(x$coefficients[3, ]))
  rownames(uninonlin) <- names(STtraits)[1]
  if (num_traits > 1) {
    for (i in 2:num_traits) {
      form <-as.formula(paste(names(Rfitness), "~", names(STtraits[i]), "+", "I(", names(STtraits[1]), "^2)"))
      x    <- summary(lm(form, dset))
      uninonlin <- rbind(uninonlin, x$coefficients[3, ])
    }
    rownames(uninonlin) <- names(STtraits)
  }
  # multiply estimates and standard errors by 2
  uninonlin[, 1] <- 2.0 * uninonlin[, 1]
  uninonlin[, 2] <- 2.0 * uninonlin[, 2]
  return(uninonlin)
}
betamatrix <- function(Rfitness, STtraits) {
  # beta matrix function + multiple regression results
  # ARGUMENTS: Rfitness = single-column data frame containing fitness variable
  #            STtraits  = matrix of traits
  # RETURNS:   everything = a list, 
  #                 $results = summary from multiple regression
  #                 $beta_matrix = beta matrix
  
  num_traits <- length(STtraits)
  dset  <- as.data.frame(cbind(Rfitness, STtraits))
  main_effects_B <- paste(names(STtraits), collapse = "+")
  formB <- as.formula(paste(names(Rfitness), "~", main_effects_B, sep = ""))
  B     <- lm(formB, dset)
  results    <- summary(B)
  everything <- list(results = results, beta_matrix = coefficients(B)[2:(num_traits + 1)])
  return(everything)
}
gammamatrix <- function(Rfitness, STtraits) {
  # gamma matrix function
  # ARGUMENTS: Rfitness = single-column data frame containing a fitness variable
  #            STtraits  = matrix of traits
  # RETURNS:   everything = a list, 
  #                 $results = summary from multiple regression
  #                 $gamma_matrix = gamma matrix
  
  num_traits  <- length(STtraits)
  trait_names <- names(STtraits)
  dset <- as.data.frame(cbind(Rfitness, STtraits))
  
  for (i in 1:num_traits) {
    for (j in i:num_traits) {
      newterm    <- STtraits[ ,i] * STtraits[ ,j]
      temp_names <- names(STtraits)
      STtraits   <- cbind(STtraits, newterm)
      names(STtraits) <- c(temp_names, paste(names(STtraits)[i], names(STtraits)[j], sep = "_"))
    }
  }
  
  main_effects_L <- paste(names(STtraits), collapse = "+")
  formL <- as.formula(paste(names(Rfitness), "~", main_effects_L, sep = ""))
  dset  <- as.data.frame(cbind(Rfitness, STtraits))
  G     <- lm(formL, dset)
  results <- summary(G)
  
  gamma <- matrix(rep(0.0, num_traits * num_traits), nrow = num_traits)
  index <- num_traits + 2
  for (i in 1:num_traits) {
    for (j in i:num_traits) {
      # multiply quadratic terms by 2
      if (i == j) gamma[i, j] <- 2.0 * G$coefficients[index]
      else gamma[i, j] <- G$coefficients[index]
      gamma[j, i] <- gamma[i, j]
      index <- index + 1
    }
  }
  rownames(gamma) <- trait_names
  colnames(gamma) <- trait_names
  everything <- list(results = results, gamma_matrix = gamma)
  return(everything)
}
canrot <- function(gamma, STtraits) {
  # Performs canonical rotation of gamma matrix
  # ARGUMENTS: gamma  = gamma matrix
  #			       traits = trait matrix
  # RETURNS:   list of $scores = transformed scores 
  #                    $M = M matrix (eigenvectors)
  #                    $lambdas = lambdas (eignevalues)
  
  num_traits <- length(STtraits)
  
  # calculate canonical coefficients
  M       <- eigen(gamma)$vectors # eigenvectors
  lambdas <- eigen(gamma)$values  # eigenvalues
  y <- as.matrix(STtraits) %*% M
  
  y <- as.data.frame(y)
  for (i in 1:num_traits) {
    names(y)[i] <- paste("M", i, sep = "")
  }
  colnames(M) <- colnames(y)
  rownames(M) <- names(STtraits)
  names(lambdas) <- colnames(M)
  
  return (list(scores = y, M = M, lambdas = lambdas))	
}
canrotsigDR <- function(CR, Rfitness) {
  # Does double-regression method for determining significance of theta and 
  # lambda parameters from canonical rotation analysis.
  # Heavily edited from supplement S1 of Reynolds et. al., Evolution, 2010
  
  # ARGUMENTS: CR = Output from function 'canrot'
  #            Rfitness = single-column data frame containing a fitness variable
  
  # RETURNS:   tstat = F-statistic for each linear and quadratic parameter (theta and lambda)
  #            pval = p values for each linear and quadratic paramter (theta and lambda)
  #            can_coef = theta/ lambda coefficients
  #            modelsum = summary of linear model (for standard errors)
  #            $model = double regression model(for prediction)
  
  y <- CR$scores
  num_traits <- length(colnames(y))
  num <- num_traits + 1
  for (i in 1:num_traits) {
    for (j in i:num_traits) {
      newterm <- y[ ,i] * y[ ,j]
      y <- cbind(y, newterm)
      names(y)[num] <- paste("M", i, "M", j, sep = "")
      num <- num + 1
    }
  }
  
  main_effects_Y <- paste(names(y), collapse = "+")
  forml <- as.formula(paste(names(Rfitness), "~", main_effects_Y, sep = ""))
  dset1 <- as.data.frame(cbind(Rfitness, y))
  L     <- lm(forml, dset1)
  
  # pick off p-values from double regression
  DRsum   <- Anova(L, type = "III") # not sure why Reynolds et al. 2010 use instead of t-stat^2 from lm; would be faster
  idx     <- num_traits + 2
  DRpval  <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
  DRtstat <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
  DRpval  <- as.data.frame(DRpval)
  DRtstat <- as.data.frame(DRtstat)
  
  for (i in 1:num_traits) {
    DRpval[i]  <- DRsum$"Pr(>F)"[i + 1]
    DRtstat[i] <- DRsum$"F value"[i + 1]
    if (i == 1) theta <- L$coefficients[i + 1] 
    else theta <- cbind(theta, L$coefficients[i + 1])
    names(DRpval)[i] <- paste("theta", rownames(DRsum)[i + 1])
    for (j in i:num_traits) {
      if (i == j) {
        DRpval[i + num_traits] <- DRsum$"Pr(>F)"[idx]
        DRtstat[i + num_traits] <- DRsum$"F value"[idx]
        names(DRpval)[i + num_traits] <- paste("lambda", rownames(DRsum)[idx])
      }
      idx <- idx + 1
    }
  }
  names(DRtstat) <- names(DRpval)
  can_coef <- c(theta, CR$lambdas)
  names(can_coef) <- names(DRpval)
  
  return (list(tstat = DRtstat, pval = DRpval, can_coef = can_coef, modelsum = summary(L), model = L))
}
canrotsig <- function(CR, STtraits, Rfitness, method, num_perm) {
  # function to determine significance of theta and lambda parameters using a permutation test
  # ARGUMENTS: CR       = Output from function 'canrot'
  #			       STtraits = trait matrix
  #            Rfitness = single-column data frame containing a fitness variable
  #		       	 method   = method for permutation (PF = permute fitness, PCR = Reynolds et al. 2010 method, ALL = both methods) NOTE: always does Double Regression
  #            num_perm = number of permutations
  # RETURNS:   a list, $results = theta and lambda parameters with p-values
  #                    $eigenvec = eigenvectors (M matrix)
  #                    $modelsum = double regression model summary (for standard errors)
  #                    $model = double regression model (for prediction)
  
  DR <- canrotsigDR(CR, Rfitness)
  num_traits <- length(STtraits)
  if (method == "PF" | method == "ALL") {
    # This reassigns fitness to each new canonical variate. This is what is suggested in the Adaptive Landscapes book for assessing the significance of a particular canonical variate.
    
    x <- mclapply(X = 1:num_perm, 
                  FUN = function(x) {
                    permfit <- sample(Rfitness[, 1]) 
                    pDR <- canrotsigDR(CR, as.data.frame(permfit))
                    return(pDR$tstat)
                  })
    
    stat_track <- x[[1]]
    for (i in 2:num_perm) {
      stat_track <- rbind(stat_track, x[[i]])
    }
    
    pfvalues <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
    for (c in 1: (num_traits * 2)) {
      pfvalues[c] <- mean(stat_track[, c] > DR$tstat[, c])
    }
    pfvalues <- as.data.frame(pfvalues)
    names(pfvalues) <- names(DR$pval)
  }
  
  if (method == "PCR" | method == "ALL") {
    # Permutation test of canonical coefficients from supplement S1 of Reynolds et. al., but extensively rewritten.
    # The main difference is that fitness is randomized amongst the original traits.
    
    x <- mclapply(X = 1:num_perm, 
                  FUN = function(x) {
                    permfit <- sample(Rfitness[, 1]) 
                    pgamma  <- gammamatrix(as.data.frame(permfit), STtraits)               
                    pCR <- canrot(pgamma[[2]], STtraits)
                    pDR <- canrotsigDR(pCR, as.data.frame(permfit))
                    return(pDR$tstat)
                  })
    
    stat_track <- x[[1]]
    for (i in 2:num_perm) {
      stat_track <- rbind(stat_track, x[[i]])
    }
    
    pcrvalues <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
    for (c in 1: (num_traits * 2)) {
      pcrvalues[c] <- mean(stat_track[, c] > DR$tstat[, c])
    }
    pcrvalues <- as.data.frame(pcrvalues)
    names(pcrvalues) <- names(DR$pval)
  }
  
  if (method == "PF") {
    results <- rbind(DR$can_coef, DR$pval, pfvalues)
    rownames(results) <- c("Theta/Lambda(Eigenvalues)", "Double_Regression_p-values", "Permutation_p-values")
  }
  if (method == "PCR") {
    results <- rbind(DR$can_coef, DR$pval, pcrvalues)
    rownames(results) <- c("Theta/Lambda(Eigenvalues)", "Double_Regression_p-values", "Reynolds_Permutation_p-values")
  }
  if (method == "ALL") {
    results <- rbind(DR$can_coef, DR$pval, pfvalues, pcrvalues)
    rownames(results) <- c("Theta/Lambda(Eigenvalues)", "Double_Regression_p-values", "Permutation_p-values", "Reynolds_Permutation_p-values")
  }
  
  return(list(results = results, eigenvec = CR$M, modelsum = DR$modelsum, model = DR$model))
}


# 3. Call datasets

setwd("PATH")

traits_raw   <- read.table ("MultSel_TraitData.csv", header=TRUE, sep=";") # call trait dataset
traits_excl  <- traits_raw [is.na(traits_raw$EXCL...traits),] # apply exclusion
traits_excl$tt <- sqrt (traits_excl$tt) # apply data transformation
traits_excl$oo <- log10(traits_excl$oo)
traits       <- traits_excl [,c("feeler","body","shaft","brush","bristles")] # select set of traits among ba tt oo Dsv CS RWS1 RWS2 RWS3 feeler body shaft brush bristles
STtraits <- standardise(traits)[[1]] # standardize traits

fitness_raw  <- read.table ("MultSel_FitnessData.csv", header=TRUE, sep=";") # call fitness dataset
fitness_excl <- fitness_raw [is.na(fitness_raw$EXCL...traits),] # apply exclusion
fitness      <- data.frame(fitness_excl [,c("MS")]) # select fitness variable among mRS F MS STE SFE
Rfitness <- data.frame(rel(fitness)) # relativize fitness data


# 4. Compute all linear and non-linear selection parameters

seldiff(Rfitness,STtraits) # univariate selection differentials

UNInonlin(Rfitness,STtraits) # univariate nonlinear selection differentials

betamatrix(Rfitness,STtraits) # selection gradients (beta matrix)

gammamatrix(Rfitness, STtraits) # quadratic and correlationnal coefficients (gamma matrix)

canrot(gammamatrix(Rfitness,STtraits)$gamma_matrix,STtraits) # canonical rotation of gamma matrix (M matrix and lambdas)

canrotsigDR(canrot(gammamatrix(Rfitness,STtraits)$gamma_matrix,STtraits), Rfitness) # significance of theta (double-regression method)

canrotsig(canrot(gammamatrix(Rfitness,STtraits)$gamma_matrix, STtraits), STtraits, Rfitness, method="ALL", 10) # significance of theta (permutation test)


# 5. Test overall linear, quadratic, correlationnal selection on original traits

dataset        <- cbind(STtraits,Rfitness)
names(dataset) <- c(paste(names(STtraits)),paste(names(Rfitness)))

effects_L  <- paste(names(traits), collapse="+") # linear factors

effects_Q<-c() # quadratic factors
for (i in 1:length(traits)) {    
  for (j in i:length(traits)) {
    if (i==j) {effects_Q<-paste(effects_Q,paste("I(",names(traits[i]),"^2)"),sep=" + ")}
    else {""}
  }
}  

effects_C<-c() # correlational factors
for (i in 1:length(traits)) {
  for (j in i:length(traits)) {
    if(i==j) {""}
    else {effects_C<-paste(effects_C,paste(names(traits)[i],names(traits)[j],sep=":"),sep=" + ")}
  }
}

form_L   <- as.formula (paste(names(Rfitness), "~", effects_L, sep=""))
form_LQ  <- as.formula (paste(names(Rfitness), "~", effects_L, effects_Q, sep=""))
form_LQC <- as.formula (paste(names(Rfitness), "~", effects_L, effects_Q, effects_C, sep=""))

m0 <- lm(paste(names(Rfitness), "~ 1"), data=dataset)
m1 <- lm(form_L  , data=dataset)
m2 <- lm(form_LQ , data=dataset)
m3 <- lm(form_LQC, data=dataset)

summary(m0) # null model
summary(m1) # linear model
summary(m2) # linear+quadratic model
summary(m3) # linear+quadratic+correlationnal model (aka linear+nonlinear)

anova(m0,m1,m2,m3) # model comparison: linear, linear+quadratic, linear+quadratic+correlationnal

anova(m0,m1,m3) # model comparison: linear, linear+nonlinear


# 6. Test overall linear, quadratic, correlationnal selection on canonical axes

CanAxes <- canrot(gammamatrix(Rfitness,STtraits)$gamma_matrix,STtraits)$scores
dataset        <- cbind(CanAxes,Rfitness)
names(dataset) <- c(paste(names(CanAxes)),paste(names(Rfitness)))

effects_L  <- paste(names(CanAxes), collapse="+")  # linear factors

effects_Q<-c() # quadratic factors
for (i in 1:length(CanAxes)) {    
  for (j in i:length(CanAxes)) {
    if (i==j) {effects_Q<-paste(effects_Q,paste("I(",names(CanAxes[i]),"^2)"),sep=" + ")}
    else {""}
  }
}  

form_L  <- as.formula (paste(names(Rfitness), "~", effects_L, sep=""))
form_LQ <- as.formula (paste(names(Rfitness), "~", effects_L, effects_Q, sep=""))

m0 <- lm(paste(names(Rfitness), "~ 1"), data=dataset)
m1 <- lm(form_L   , data=dataset)
m2 <- lm(form_LQ  , data=dataset)

summary(m0) # null model
summary(m1) # linear model
summary(m2) # linear+quadratic model

anova(m0,m1,m2) # model comparison: linear, linear+nonlinear