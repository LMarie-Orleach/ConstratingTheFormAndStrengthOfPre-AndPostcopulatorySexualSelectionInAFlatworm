# Lucas Marie-Orleach - March 2023

# script used to carry the analyses reported in the paper entitled "Contrasting the form and strength of pre- and postcopulatory
# sexual selection in a transparent worm with fluorescent sperm" by Lucas Marie-Orleach, Matt D. Hall, and Lukas Sch�rer.

# most functions below come from the supplementary material of Keagy et al 2016 Ecol. Lett 19: 71-80.

# 1. load required packages
library(gss)
library(lme4)
library(parallel)
library(car)


# 2. Define functions

se <- function(x) {
  # function to compute standard errors
  sd(x)/sqrt(length(x)) 
} 
rel <- function(x,col) {
  # function to relativize fitness data
  (x[,col])/mean(x[,col],na.rm=TRUE) 
} 
standardise <- function(traits) {
  # function to standardise trait values
  # ARGUMENTS: traits = matrix of traits
  # RETURNS:   STtraits = matrix of standardized trait values
  #            means  = mean of each trait, before standardisation
  #            sds    = standard deviation of each trait, before standardisation
  
  STtraits <- traits
  means <- rep(NA, length(traits))
  names(means) <- colnames(traits)
  sds <- means
  for (i in 1:length(traits)) {
    means[i] <- sapply(traits[i], mean, na.rm = TRUE)
    sds[i] <- sapply(traits[i], sd, na.rm = TRUE)
    STtraits[i] <- (traits[i] - means[i]) / sds[i]
  }
  return(list(STtraits))
}
seldiff <- function(Rfitness, STtraits) {
  # univariate selection differentials function
  
  # ARGUMENTS: Rfitness = single-column data frame containing the fitness variable
  #            traits = matrix of traits
  
  # RETURNS:   sdiff = univariate selection differentials
  
  num_traits <- length(STtraits)
  dset  <- as.data.frame(cbind(Rfitness, STtraits))
  form  <- as.formula(paste(names(Rfitness), "~", names(STtraits[1])))
  x     <- summary(lm(form, dset))
  sdiff <- t(as.data.frame(x$coefficients[2, ]))
  rownames(sdiff) <- names(STtraits)[1]
  if (num_traits > 1) {
    for (i in 2:num_traits) {
      form <- as.formula(paste(names(Rfitness), "~", names(STtraits[i])))
      x <- summary(lm(form, dset))
      sdiff <- rbind(sdiff, x$coefficients[2, ])
    }
    rownames(sdiff) <- names(STtraits)
  }
  return(sdiff)
}
UNInonlin <- function(Rfitness, STtraits) {
  # univariate nonlinear selection differentials function
  # ARGUMENTS: Rfitness = single-column data frame containing fitness variable
  #            STtraits  = matrix of traits
  # RETURNS:   uninonlin = nonlinear (quadratic) selection differentials
  
  num_traits <- length(STtraits)
  dset       <- as.data.frame(cbind(Rfitness, STtraits))
  form       <- as.formula(paste(names(Rfitness), "~", names(STtraits[1]), "+", "I(", names(STtraits[1]), "^2)"))
  x          <- summary(lm(form, dset))
  uninonlin  <- t(as.data.frame(x$coefficients[3, ]))
  rownames(uninonlin) <- names(STtraits)[1]
  if (num_traits > 1) {
    for (i in 2:num_traits) {
      form <-as.formula(paste(names(Rfitness), "~", names(STtraits[i]), "+", "I(", names(STtraits[1]), "^2)"))
      x    <- summary(lm(form, dset))
      uninonlin <- rbind(uninonlin, x$coefficients[3, ])
    }
    rownames(uninonlin) <- names(STtraits)
  }
  # multiply estimates and standard errors by 2
  uninonlin[, 1] <- 2.0 * uninonlin[, 1]
  uninonlin[, 2] <- 2.0 * uninonlin[, 2]
  return(uninonlin)
}
betamatrix <- function(Rfitness, STtraits) {
  # beta matrix function + multiple regression results
  # ARGUMENTS: Rfitness = single-column data frame containing fitness variable
  #            STtraits  = matrix of traits
  # RETURNS:   everything = a list, 
  #                 $results = summary from multiple regression
  #                 $beta_matrix = beta matrix
  
  num_traits <- length(STtraits)
  dset  <- as.data.frame(cbind(Rfitness, STtraits))
  main_effects_B <- paste(names(STtraits), collapse = "+")
  formB <- as.formula(paste(names(Rfitness), "~", main_effects_B, sep = ""))
  B     <- lm(formB, dset)
  results    <- summary(B)
  everything <- list(results = results, beta_matrix = coefficients(B)[2:(num_traits + 1)])
  return(everything)
}
gammamatrix <- function(Rfitness, STtraits) {
  # gamma matrix function
  # ARGUMENTS: Rfitness = single-column data frame containing a fitness variable
  #            STtraits  = matrix of traits
  # RETURNS:   everything = a list, 
  #                 $results = summary from multiple regression
  #                 $gamma_matrix = gamma matrix
  
  num_traits  <- length(STtraits)
  trait_names <- names(STtraits)
  dset <- as.data.frame(cbind(Rfitness, STtraits))
  
  for (i in 1:num_traits) {
    for (j in i:num_traits) {
      newterm    <- STtraits[ ,i] * STtraits[ ,j]
      temp_names <- names(STtraits)
      STtraits   <- cbind(STtraits, newterm)
      names(STtraits) <- c(temp_names, paste(names(STtraits)[i], names(STtraits)[j], sep = "_"))
    }
  }
  
  main_effects_L <- paste(names(STtraits), collapse = "+")
  formL <- as.formula(paste(names(Rfitness), "~", main_effects_L, sep = ""))
  dset  <- as.data.frame(cbind(Rfitness, STtraits))
  G     <- lm(formL, dset)
  results <- summary(G)
  
  gamma <- matrix(rep(0.0, num_traits * num_traits), nrow = num_traits)
  index <- num_traits + 2
  for (i in 1:num_traits) {
    for (j in i:num_traits) {
      # multiply quadratic terms by 2
      if (i == j) gamma[i, j] <- 2.0 * G$coefficients[index]
      else gamma[i, j] <- G$coefficients[index]
      gamma[j, i] <- gamma[i, j]
      index <- index + 1
    }
  }
  rownames(gamma) <- trait_names
  colnames(gamma) <- trait_names
  everything <- list(results = results, gamma_matrix = gamma)
  return(everything)
}
canrot <- function(gamma, STtraits) {
  # Performs canonical rotation of gamma matrix
  # ARGUMENTS: gamma  = gamma matrix
  #			       traits = trait matrix
  # RETURNS:   list of $scores = transformed scores 
  #                    $M = M matrix (eigenvectors)
  #                    $lambdas = lambdas (eignevalues)
  
  num_traits <- length(STtraits)
  
  # calculate canonical coefficients
  M       <- eigen(gamma)$vectors # eigenvectors
  lambdas <- eigen(gamma)$values  # eigenvalues
  y <- as.matrix(STtraits) %*% M
  
  y <- as.data.frame(y)
  for (i in 1:num_traits) {
    names(y)[i] <- paste("M", i, sep = "")
  }
  colnames(M) <- colnames(y)
  rownames(M) <- names(STtraits)
  names(lambdas) <- colnames(M)
  
  return (list(scores = y, M = M, lambdas = lambdas))	
}
canrotsigDR <- function(CR, Rfitness) {
  # Does double-regression method for determining significance of theta and 
  # lambda parameters from canonical rotation analysis.
  # Heavily edited from supplement S1 of Reynolds et. al., Evolution, 2010
  
  # ARGUMENTS: CR = Output from function 'canrot'
  #            Rfitness = single-column data frame containing a fitness variable
  
  # RETURNS:   tstat = F-statistic for each linear and quadratic parameter (theta and lambda)
  #            pval = p values for each linear and quadratic paramter (theta and lambda)
  #            can_coef = theta/ lambda coefficients
  #            modelsum = summary of linear model (for standard errors)
  #            $model = double regression model(for prediction)
  
  y <- CR$scores
  num_traits <- length(colnames(y))
  num <- num_traits + 1
  for (i in 1:num_traits) {
    for (j in i:num_traits) {
      newterm <- y[ ,i] * y[ ,j]
      y <- cbind(y, newterm)
      names(y)[num] <- paste("M", i, "M", j, sep = "")
      num <- num + 1
    }
  }
  
  main_effects_Y <- paste(names(y), collapse = "+")
  forml <- as.formula(paste(names(Rfitness), "~", main_effects_Y, sep = ""))
  dset1 <- as.data.frame(cbind(Rfitness, y))
  L     <- lm(forml, dset1)
  
  # pick off p-values from double regression
  DRsum   <- Anova(L, type = "III") # not sure why Reynolds et al. 2010 use instead of t-stat^2 from lm; would be faster
  idx     <- num_traits + 2
  DRpval  <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
  DRtstat <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
  DRpval  <- as.data.frame(DRpval)
  DRtstat <- as.data.frame(DRtstat)
  
  for (i in 1:num_traits) {
    DRpval[i]  <- DRsum$"Pr(>F)"[i + 1]
    DRtstat[i] <- DRsum$"F value"[i + 1]
    if (i == 1) theta <- L$coefficients[i + 1] 
    else theta <- cbind(theta, L$coefficients[i + 1])
    names(DRpval)[i] <- paste("theta", rownames(DRsum)[i + 1])
    for (j in i:num_traits) {
      if (i == j) {
        DRpval[i + num_traits] <- DRsum$"Pr(>F)"[idx]
        DRtstat[i + num_traits] <- DRsum$"F value"[idx]
        names(DRpval)[i + num_traits] <- paste("lambda", rownames(DRsum)[idx])
      }
      idx <- idx + 1
    }
  }
  names(DRtstat) <- names(DRpval)
  can_coef <- c(theta, CR$lambdas)
  names(can_coef) <- names(DRpval)
  
  return (list(tstat = DRtstat, pval = DRpval, can_coef = can_coef, modelsum = summary(L), model = L))
}
canrotsig <- function(CR, STtraits, Rfitness, method, num_perm) {
  # function to determine significance of theta and lambda parameters using a permutation test
  # ARGUMENTS: CR       = Output from function 'canrot'
  #			       STtraits = trait matrix
  #            Rfitness = single-column data frame containing a fitness variable
  #		       	 method   = method for permutation (PF = permute fitness, PCR = Reynolds et al. 2010 method, ALL = both methods) NOTE: always does Double Regression
  #            num_perm = number of permutations
  # RETURNS:   a list, $results = theta and lambda parameters with p-values
  #                    $eigenvec = eigenvectors (M matrix)
  #                    $modelsum = double regression model summary (for standard errors)
  #                    $model = double regression model (for prediction)
  
  DR <- canrotsigDR(CR, Rfitness)
  num_traits <- length(STtraits)
  if (method == "PF" | method == "ALL") {
    # This reassigns fitness to each new canonical variate. This is what is suggested in the Adaptive Landscapes book for assessing the significance of a particular canonical variate.
    
    x <- mclapply(X = 1:num_perm, 
                  FUN = function(x) {
                    permfit <- sample(Rfitness[, 1]) 
                    pDR <- canrotsigDR(CR, as.data.frame(permfit))
                    return(pDR$tstat)
                  })
    
    stat_track <- x[[1]]
    for (i in 2:num_perm) {
      stat_track <- rbind(stat_track, x[[i]])
    }
    
    pfvalues <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
    for (c in 1: (num_traits * 2)) {
      pfvalues[c] <- mean(stat_track[, c] > DR$tstat[, c])
    }
    pfvalues <- as.data.frame(pfvalues)
    names(pfvalues) <- names(DR$pval)
  }
  
  if (method == "PCR" | method == "ALL") {
    # Permutation test of canonical coefficients from supplement S1 of Reynolds et. al., but extensively rewritten.
    # The main difference is that fitness is randomized amongst the original traits.
    
    x <- mclapply(X = 1:num_perm, 
                  FUN = function(x) {
                    permfit <- sample(Rfitness[, 1]) 
                    pgamma  <- gammamatrix(as.data.frame(permfit), STtraits)               
                    pCR <- canrot(pgamma[[2]], STtraits)
                    pDR <- canrotsigDR(pCR, as.data.frame(permfit))
                    return(pDR$tstat)
                  })
    
    stat_track <- x[[1]]
    for (i in 2:num_perm) {
      stat_track <- rbind(stat_track, x[[i]])
    }
    
    pcrvalues <- matrix(rep(0.0, num_traits * 2), ncol = num_traits * 2)
    for (c in 1: (num_traits * 2)) {
      pcrvalues[c] <- mean(stat_track[, c] > DR$tstat[, c])
    }
    pcrvalues <- as.data.frame(pcrvalues)
    names(pcrvalues) <- names(DR$pval)
  }
  
  if (method == "PF") {
    results <- rbind(DR$can_coef, DR$pval, pfvalues)
    rownames(results) <- c("Theta/Lambda(Eigenvalues)", "Double_Regression_p-values", "Permutation_p-values")
  }
  if (method == "PCR") {
    results <- rbind(DR$can_coef, DR$pval, pcrvalues)
    rownames(results) <- c("Theta/Lambda(Eigenvalues)", "Double_Regression_p-values", "Reynolds_Permutation_p-values")
  }
  if (method == "ALL") {
    results <- rbind(DR$can_coef, DR$pval, pfvalues, pcrvalues)
    rownames(results) <- c("Theta/Lambda(Eigenvalues)", "Double_Regression_p-values", "Permutation_p-values", "Reynolds_Permutation_p-values")
  }
  
  return(list(results = results, eigenvec = CR$M, modelsum = DR$modelsum, model = DR$model))
}


# 3. Call datasets

setwd("PATH")

traits_raw   <- read.table ("MultSel_TraitData.csv", header=TRUE, sep=";") # call trait dataset
traits_excl  <- traits_raw [is.na(traits_raw$EXCL...traits),] # apply exclusion
traits_excl$tt <- sqrt (traits_excl$tt) # apply data transformation
traits_excl$oo <- log10(traits_excl$oo)
traits       <- traits_excl [,c("CS","RWS1","RWS2","RWS3")] # select set of traits among ba tt oo Dsv CS RWS1 RWS2 RWS3 feeler body shaft brush bristles
STtraits <- standardise(traits)[[1]] # standardize traits

fitness_raw  <- read.table ("MultSel_FitnessData.csv", header=TRUE, sep=";") # call fitness dataset
fitness_excl <- fitness_raw [is.na(fitness_raw$EXCL...traits),] # apply exclusion
fitness      <- data.frame(fitness_excl [,c("Focal.ID","F","SFE")]) ## select 2 fitness variables among mRS F PMS STE SFE
fitness$w1 <- rel(fitness,2)
fitness$w2 <- rel(fitness,3)
Rfitness   <- data.frame(fitness[,c("Focal.ID","w1","w2")]) # relativize fitness

dataset1         <- cbind(Rfitness[,c("Focal.ID","w1")],STtraits)
dataset1$episode <- colnames(fitness[2])
names(dataset1)  <- c ("Focal.ID","Rfitness", paste(names(STtraits)), "episode")

dataset2         <- cbind(Rfitness[,c("Focal.ID","w2")],STtraits)
dataset2$episode <- colnames(fitness[3])
names(dataset2)  <- c ("Focal.ID","Rfitness", paste(names(STtraits)), "episode")

dataset <- rbind(dataset1,dataset2) ##bind the two datasets


# 4. Pair-wise test for interactions between fitness components on original traits

# 4.1
effects_L  <- paste(names(STtraits[1:length(STtraits)]), collapse="+")# linear factors

effects_L_X<-c() # component x linear factors
for(i in 1:length(STtraits)) {
  effects_L_X <- paste(effects_L_X,paste("episode:",names(STtraits)[i],sep=""),sep=" + ")
}

effects_Q<-c() # quadratic factors
for (i in 1:length(STtraits)) {    
  for (j in i:length(STtraits)) {
    if (i==j) {effects_Q<-paste(effects_Q,paste("I(",names(STtraits[i]),"^2)"),sep=" + ")}
    else {""}
  }
}  

effects_Q_X<-c() # # components x quadratic factors 
for (i in 1:length(STtraits)) {    
  for (j in i:length(STtraits)) {
    if (i==j) {effects_Q_X<-paste(effects_Q_X,paste("episode:I(",names(STtraits[i]),"^2)"),sep=" + ")}
    else {""}
  }
} 

effects_C<-c() # # correlationnal factors
for (i in 1:length(STtraits)) {
  for (j in i:length(STtraits)) {
    if(i==j) {""}
    else {effects_C<-paste(effects_C,paste(names(STtraits)[i],names(STtraits)[j],sep=":"),sep=" + ")}
  }
}

effects_C_X<-c() # # components x correlationnal factors 
for (i in 1:length(STtraits)) {
  for (j in i:length(STtraits)) {
    if(i==j) {""}
    else {effects_C_X<-paste(effects_C_X,paste("episode",names(STtraits)[i],names(STtraits)[j],sep=":"),sep=" + ")}
  }
}

form_L        <- as.formula(paste("Rfitness ~ episode +", effects_L, sep=""))
form_LX       <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, sep=""))
form_LX_Q     <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, effects_Q, sep=""))
form_LX_QX    <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, sep=""))
form_LX_QX_C  <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, effects_C, sep=""))
form_LX_QX_CX <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, effects_C, effects_C_X, sep=""))

m0<-lm(Rfitness ~ episode, data=dataset) # null model
m1<-lm(form_L       , data=dataset) # linear model
m2<-lm(form_LX      , data=dataset) # component x linear model
m3<-lm(form_LX_Q    , data=dataset) # linear+quadratic model
m4<-lm(form_LX_QX   , data=dataset) # component x linear+quadratic model
m5<-lm(form_LX_QX_C , data=dataset) # linear+quadratic+correlationnal model
m6<-lm(form_LX_QX_CX, data=dataset) # component x linear+quadratic+correlationnal model

summary(m0)
summary(m1)
summary(m2)
summary(m3)
summary(m4)
summary(m5)
summary(m6)

anova(m0,m1,m2,m3,m4,m5,m6) # model comparison: linear, linear+quadratic, linear+quadratic+correlationnal

form_LX_QC  <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, effects_Q, effects_C, sep=""))
m7 <- lm(form_LX_QC, data=dataset) # component x linear+non-linear model

anova(m0,m1,m2,m7,m6) # model comparison: linear, linear+nonlinear


# 4.2 with focal.ID as a random effect

form_L        <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, sep=""))
form_LX       <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, sep=""))
form_LX_Q     <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, effects_Q, sep=""))
form_LX_QX    <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, sep=""))
form_LX_QX_C  <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, effects_C, sep=""))
form_LX_QX_CX <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, effects_C, effects_C_X, sep=""))

m0<-lmer(Rfitness ~ (1|Focal.ID) + episode, data=dataset) # null model
m1<-lmer(form_L       , data=dataset) # linear model
m2<-lmer(form_LX      , data=dataset) # component x linear model
m3<-lmer(form_LX_Q    , data=dataset) # linear+quadratic model
m4<-lmer(form_LX_QX   , data=dataset) # component x linear+quadratic model
m5<-lmer(form_LX_QX_C , data=dataset) # linear+quadratic+correlationnal model (aka linear+nonlinear)
m6<-lmer(form_LX_QX_CX, data=dataset) # component x linear+quadratic+correlationnal model (aka component x linear+nonlinear)

summary(m0)
summary(m1)
summary(m2)
summary(m3)
summary(m4)
summary(m5)
summary(m6)

anova(m0,m1,m2,m3,m4,m5,m6) # model comparison: linear, linear+quadratic, linear+quadratic+correlationnal

form_LX_QC  <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, effects_Q, effects_C, sep=""))
m7 <- lm(form_LX_QC, data=dataset) # component x linear+non-linear model
anova(m0,m1,m2,m7,m6) # model comparison: linear, linear+nonlinear


# 5. Pair-wise test for interactions between fitness components on canonical axes

# 5.1

Rfitness <- data.frame(dataset$Rfitness)
STtraits <- dataset[,c(3:(length(dataset)-1))]
CanAxes <- canrot(gammamatrix(Rfitness,STtraits)$gamma_matrix, STtraits)$scores # compute canonical scores

dataset3 <- cbind(CanAxes,Rfitness,dataset$episode,dataset$Focal.ID) # bind canonical scores with success and episode
names(dataset3)<-c(paste(names(CanAxes)),"Rfitness","episode","Focal.ID")

effects_L  <- paste(names(CanAxes), collapse="+") # linear factors

effects_L_X<-c() # episode x linear factors
for(i in 1:length(CanAxes)) {
  effects_L_X <- paste(effects_L_X,paste("episode:",names(CanAxes)[i],sep=""),sep=" + ")
}

effects_Q<-c() # quadratic factors
for (i in 1:length(CanAxes)) {    
  for (j in i:length(CanAxes)) {
    if (i==j) {effects_Q<-paste(effects_Q,paste("I(",names(CanAxes[i]),"^2)"),sep=" + ")}
    else {""}
  }
}  

effects_Q_X<-c()# episode x quadratic factors
for (i in 1:length(CanAxes)) {    
  for (j in i:length(CanAxes)) {
    if (i==j) {effects_Q_X<-paste(effects_Q_X,paste("episode:I(",names(CanAxes[i]),"^2)"),sep=" + ")}
    else {""}
  }
}  

form_L    <- as.formula(paste("Rfitness ~ episode +", effects_L, sep=""))
form_L_X  <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, sep=""))
form_LQ   <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, effects_Q, sep=""))
form_LQ_X <- as.formula(paste("Rfitness ~ episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, sep=""))

m0<-lm(Rfitness ~ episode, data=dataset3) # null model
m1<-lm(form_L    , data=dataset3) # linear model
m2<-lm(form_L_X  , data=dataset3) # component x linear model
m3<-lm(form_LQ   , data=dataset3) # linear+nonlinear model
m4<-lm(form_LQ_X , data=dataset3) # component x nonlinear model

summary(m0)
summary(m1)
summary(m2)
summary(m3)
summary(m4)

anova(m0,m1,m2,m3,m4) # model comparison: linear, linear+nonlinear


# 5.2 with focal.ID as a random effect

form_L    <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, sep=""))
form_L_X  <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, sep=""))
form_LQ   <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, effects_Q, sep=""))
form_LQ_X <- as.formula(paste("Rfitness ~ (1|Focal.ID) + episode +", effects_L, effects_L_X, effects_Q, effects_Q_X, sep=""))

m0<-lmer(Rfitness ~ (1|Focal.ID) + episode, data=dataset3) # null model
m1<-lmer(form_L    , data=dataset3) # linear model
m2<-lmer(form_L_X  , data=dataset3) # component x linear model
m3<-lmer(form_LQ   , data=dataset3) # linear+nonlinear model
m4<-lmer(form_LQ_X , data=dataset3) # component x nonlinear model

summary(m0)
summary(m1) 
summary(m2)
summary(m3)
summary(m4)

anova(m0,m1,m2,m3,m4) # model comparison: linear, linear+nonlinear
